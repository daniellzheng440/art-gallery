Since we use php in this assignment, PLEASE GO TO http://www.scs.ryerson.ca/~zhzheng/art_gallery_v2 for the full functionality.

Instruction:
1. hover your mouse over the tag of art pieces or the tag of artist and a list will appear.
2. click on one of the item on the list and two windows will appear on the same screen.
3. your can click on the name of the art work for artist to see the full information on another window which is written in php,so it won't work properly if you open with 
   local directory.
4. you can then click the shopping cart and enter a quanity and pick a shipping plan. The total price will vary depend on what you pick.

DisClaimer:
1. The shopping cart on the main page will only give you a fixed price for what you choose.
