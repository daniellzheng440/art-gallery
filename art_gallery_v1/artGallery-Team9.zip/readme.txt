By: Zhong Zheng & Abdeali Daginawala

Instruction:
1. open the index.html file in the folder
2. hover your mouse over the tag of art pieces or the tag of artist and a list will appear.
3. click on one of the item on the list and two windows will appear on the same screen.
4. your can repeat the process above and select any other tag

If any of the above steps does not work, go to http://www.scs.ryerson.ca/~zhzheng/art_gallery which is the online domain for this assignment.